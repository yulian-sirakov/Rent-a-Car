﻿namespace Bussines_Layer.Enums
{
    public enum ReservationStatus
    {
        Confirmed,
        Active,
        Canceled
    }

}
